
package Admin;
import db.Myconnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class teachercourseview {
    Connection con = Myconnection.getConnection();
    PreparedStatement ps;
    
    
    //get all course values from database course table
    public void getcourseValue(JTable table, String searchValue){
        String sql="select*from course where concat(id,student_id,semester)like ? order by id desc";
        try {
            ps=con.prepareStatement(sql);
            ps.setString(1,"%"+searchValue+"%");
            ResultSet rs=ps.executeQuery();
            DefaultTableModel model= (DefaultTableModel) table.getModel();
            Object[] row;
            while(rs.next()){
                row = new Object[8];
                row[0]=rs.getInt(1);
                row[1]=rs.getString(2);
                row[2]=rs.getString(3);
                row[3]=rs.getString(4);
                row[4]=rs.getString(5);
                row[5]=rs.getString(6);
                row[6]=rs.getString(7);
                row[7]=rs.getString(8);
                model.addRow(row);
            }
        } catch (SQLException ex) {
            Logger.getLogger(teachercourseview.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
